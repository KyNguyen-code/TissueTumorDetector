**:red[Mô có khối u]** là một khối mô rắn hình thành khi các tế bào phát triển và phân chia nhiều hơn mức cần thiết hoặc không chết theo quy trình (apoptosis)

